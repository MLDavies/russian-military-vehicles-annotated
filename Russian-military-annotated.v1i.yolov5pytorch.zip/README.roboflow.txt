
Russian-military-annotated - v1 2022-04-25 1:09pm
==============================

This dataset was exported via roboflow.ai on April 25, 2022 at 5:12 PM GMT

It includes 993 images.
Vehicles are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


