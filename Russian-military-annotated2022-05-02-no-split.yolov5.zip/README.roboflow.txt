
Russian-military-annotated - v3 2022-05-02 no-split
==============================

This dataset was exported via roboflow.ai on May 2, 2022 at 10:52 PM GMT

It includes 993 images.
Vehicles are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


