# undefined > 2022-05-02 no-split
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: CC BY 4.0

Russian Military Vehicles (10 classes) annotated for object detection.

Dataset generously provided by:

Tuomo Hiippala
Digital Geography Lab
Department of Geosciences and Geography
University of Helsinki, Finland
E-mail: tuomo.hiippala@iki.fi