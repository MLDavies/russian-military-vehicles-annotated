
Russian-military-annotated - v4 2022-06-13 with null images
==============================

This dataset was exported via roboflow.ai on June 14, 2022 at 12:18 AM GMT

It includes 1042 images.
Vehicles are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


