
Russian-military-annotated - v2 2022-04-25 rebalance T-V-T split
==============================

This dataset was exported via roboflow.ai on April 25, 2022 at 11:37 PM GMT

It includes 993 images.
Vehicles are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


