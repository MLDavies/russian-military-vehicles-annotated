# undefined > 2022-04-25 rebalance T-V-T split
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: CC BY 4.0

Russian Military Vehicles (10 classes) annotated for object detection.

Dataset generously provided by:

Tuomo Hiippala
Digital Geography Lab
Department of Geosciences and Geography
University of Helsinki, Finland
E-mail: tuomo.hiippala@iki.fi